function [output] = conv_layer_forward(input, layer, param)
% Conv layer forward
% input: struct with input data
% layer: convolution layer struct
% param: weights for the convolution layer

% output: 

h_in = input.height;
w_in = input.width;
c = input.channel;
batch_size = input.batch_size;
k = layer.k;
pad = layer.pad;
stride = layer.stride;
num = layer.num;
% resolve output shape
h_out = (h_in + 2*pad - k) / stride + 1;
w_out = (w_in + 2*pad - k) / stride + 1;

assert(h_out == floor(h_out), 'h_out is not integer')
assert(w_out == floor(w_out), 'w_out is not integer')
input_n.height = h_in;
input_n.width = w_in;
input_n.channel = c;

%% Fill in the code
% Iterate over the each image in the batch, compute response,
% Fill in the output datastructure with data, and the shape. 
output.height = h_out;
output.width = w_out;
output.channel = num;
output.batch_size = batch_size;

output.data = zeros(h_out, w_out, num, batch_size);

batch = input.data;

for b = 1:batch_size
%     disp(b);
%     disp(size(data_batch(:,b)));
%     disp([h_in, w_in, c]);
    if ndims(batch) == 2
%         disp(size(batch(:,b)));
%         disp([h_in, w_in, c]);
        data = reshape(batch(:,b), [h_in, w_in, c]);
    elseif ndims(batch) == 4
        data = reshape(batch(:,:,:,b), [h_in, w_in, c]);
    end
    data = padarray(data, [pad pad]);
    [row, col, ~] = size(data);
    for w = 1:num
        W = param.w(:,w);
        W = reshape(W, [k k c]);
        for i = 1:stride:row
            for j = 1:stride:col
                if (i+k-1 <= row && j+k-1 <= col)
                    window = data(i:i+k-1, j:j+k-1, :);
                    temp = sum(window .* W, 'all') + param.b(w);
                    output.data(ceil(i/stride), ceil(j/stride), w, b) = temp;
                end
            end
        end
    end
end
% input.data = reshape(input.data,h_in,w_in,c,batch_size);
% for b = 1:batch_size
%     data = padarray(input.data(:,:,:,b), [pad pad], 0, 'both');
%     for w = 1:num
%         weight = param.w(:,:,:,w);
%         for i = 0:h_out-1
%             for j = 0:w_out-1
%                 sub = data(stride*i+1:stride*i+k, stride*j+1:stride*j+k, :);
%                 output.data(i+1,j+1,w,b) = sum((sub .* weight), 'all') + param.b(w);
%             end
%         end
%     end
% end
output.data = reshape(output.data, [h_out*w_out*num, batch_size]);


end

