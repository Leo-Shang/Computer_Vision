fprintf('compute dictionary \n');
computeDictionary;

fprintf('build recognition system \n');
buildRecognitionSystem;

fprintf('evaluate recognition system \n');
evaluateRecognitionSystem_NN;

fprintf('evaluate recognition system kNN \n');
evaluateRecognitionSystem_kNN;